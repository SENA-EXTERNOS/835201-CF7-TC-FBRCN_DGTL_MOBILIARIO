function ExecuteScript(strId)
{
  switch (strId)
  {
      case "65RvkUi79Xk":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

